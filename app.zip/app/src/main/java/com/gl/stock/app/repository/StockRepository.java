package com.gl.stock.app.repository;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.stereotype.Repository;

import com.gl.stock.app.entity.Stock;

import reactor.core.publisher.Flux;

@Repository
public class StockRepository {

	private String[] listofStock = { "Tata", "Vivo", "Adani Wilmar", "Google", "Mi" };
	List<Stock> stockList = new ArrayList<>();
	public List<Stock> getAllStocksList() {

		

		return IntStream
				.range(1, 20)
				.peek(i -> delay())
				.peek(i -> System.out.println("the stock val is " + i))
				.mapToObj(i -> new Stock(ThreadLocalRandom.current().nextInt(70, 200),
						listofStock[new Random().nextInt(listofStock.length)]))
				.collect(Collectors.toList());

	}

	private void delay() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Flux<Stock> getAllStocksListNon() { 

		return Flux.range(1, 30).delayElements(Duration.ofSeconds(1))
				.doOnNext(i -> System.out.println("the stock val is " + i))
				.map(i -> new Stock(ThreadLocalRandom.current().nextInt(70, 200),

						listofStock[new Random().nextInt(listofStock.length)]))
				 ;

	}

}
