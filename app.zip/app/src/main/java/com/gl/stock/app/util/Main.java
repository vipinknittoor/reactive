package com.gl.stock.app.util;

import java.util.stream.IntStream;

public class Main {
	
	public static void main(String[] args) {
	 
	
}

}
