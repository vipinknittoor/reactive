package com.gl.stock.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.stock.app.entity.Stock;
import com.gl.stock.app.service.StockService;

import reactor.core.publisher.Flux;

@RestController
public class StockController {

	@Autowired
	StockService stockService;

	@GetMapping("/api/stocks")
	public ResponseEntity<List> getAllStockList() {
		List stockList;
		System.out.println("inside controller");
		stockList = stockService.getAllStockList();

		ResponseEntity<List> responseEntity = new ResponseEntity<List>(stockList, HttpStatus.OK);
		return responseEntity;

	}
	
	
// controller to get the name of the stock given the id 
	
//	@GetMapping("/api/stock/{id}")
//	public Stock get_Stock() {
//		 
//		System.out.println("inside controller get_Stock"); 
//		return responseEntity;
//
//	}
	
	

	@GetMapping(value = "/api/stocksr", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<Stock> getAllStockr() {
		return stockService.getAllStockr();

	}
	
	
	// controller to get the name of the stock given the id where the output format is 
	//Stream of data 
	
	
	// req  writea test suite at controller layer that test the functionality 


}
