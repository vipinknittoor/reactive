package com.gl.stock.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.stock.app.entity.Stock;
import com.gl.stock.app.repository.StockRepository;

import reactor.core.publisher.Flux;

@Service
public class StockService {
	
	@Autowired
	StockRepository stockRepository;
	
 

	public List<Stock> getAllStockList() {
		// TODO Auto-generated method stub
		return stockRepository.getAllStocksList();
	}



	public Flux<Stock> getAllStockr() {
		// TODO Auto-generated method stub
		return stockRepository.getAllStocksListNon();
	}
}
